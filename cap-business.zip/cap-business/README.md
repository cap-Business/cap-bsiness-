# Cap Business — serveur + PWA

## Lancer en local
1. Installer Node.js (v18 ou plus).
2. Dans ce dossier : `npm install express express-rate-limit @anthropic-ai/sdk`
3. Mac/Linux : `ANTHROPIC_API_KEY=ta-cle npm start`
   Windows (PowerShell) : `$env:ANTHROPIC_API_KEY="ta-cle"; npm start`
4. Ouvrir http://localhost:3000

## Mettre en ligne (Render, par exemple)
- Envoie ce dossier sur GitHub (le fichier .env ne doit jamais y aller).
- Sur render.com : New > Web Service, build `npm install express express-rate-limit @anthropic-ai/sdk`, start `npm start`.
- Ajoute la variable d'environnement ANTHROPIC_API_KEY. Ne mets jamais la clé dans la page.
- Dans la console Anthropic, fixe une limite de dépense mensuelle.

## Play Store
1. Vérifie que ton site en https s'installe bien depuis Chrome (menu > Installer l'application).
2. Va sur pwabuilder.com, entre l'adresse de ton site, choisis Android et télécharge le fichier .aab.
3. Crée un compte sur Google Play Console (25 $), puis publie l'.aab avec description, captures d'écran et politique de confidentialité.
