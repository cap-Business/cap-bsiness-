import express from "express";
import rateLimit from "express-rate-limit";
import Anthropic from "@anthropic-ai/sdk";

const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "50kb" }));
app.use(express.static("public"));

const client = new Anthropic(); // lit ANTHROPIC_API_KEY dans l'environnement
const MODEL = process.env.MODEL || "claude-sonnet-5-5";

// Limite par personne : 15 messages par minute
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 15 }));

function valid(m) {
  return Array.isArray(m) && m.length >= 1 && m.length <= 21 &&
    m[0].role === "user" && m[m.length - 1].role === "user" &&
    m.every(x => ["user", "assistant"].includes(x.role) &&
      typeof x.content === "string" && x.content.length <= 4000);
}

app.post("/api/chat", async (req, res) => {
  let m = req.body.input;
  if (typeof m === "string") m = [{ role: "user", content: m }];
  if (!valid(m)) return res.status(400).json({ error: "bad_request" });
  try {
    const r = await client.messages.create({ model: MODEL, max_tokens: 700, messages: m });
    res.json({ text: r.content.filter(b => b.type === "text").map(b => b.text).join("") });
  } catch (e) {
    console.error(e.message);
    res.status(500).json({ error: "server_error" });
  }
});

app.listen(process.env.PORT || 3000, () => console.log("Cap Business prêt"));
